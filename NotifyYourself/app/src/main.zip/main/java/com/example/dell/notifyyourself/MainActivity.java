package com.example.dell.notifyyourself;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Message;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import java.util.Set;
import java.util.UUID;


public class MainActivity extends AppCompatActivity {
    //  SharedPreferences SP = getApplicationContext().getSharedPreferences("NAME", 0);

    //declarations
    BluetoothManager mBluetoothManager;
    BluetoothAdapter bluetoothAdapter;
    Button discover,someTips,logout,records,finddevice;
    TextView status,msg_box,textView;
    SendReceive sendReceive;
    BluetoothDevice[] btArray;
    ArrayAdapter<String> arrayAdapter;
    BluetoothDevice bluetoothDevice1;
    //DatabaseHelper databaseHelper;

    //NAME THE DEVICE
    String BT_NAME = "HC-06";
    static final int STATE_LISTENING=1;// now listening for incoming connections
    static final int STATE_CONNECTING=2;// now initiating an outgoing connection
    static final int STATE_CONNECTED=3;// now connected to a remote device
    static final int STATE_CONNECTION_FAILED=4;
    static final int STATE_MESSAGE_RECEIVED=5;
    int REQUEST_ENABLE_BLUETOOTH=1;
    private static  final String APP_Name="Notify Yourself";
    private static  final UUID MY_UUID=UUID.fromString("8ce255c0-200a-11e0-ac64-0800200c9a66");

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkUser();
        findViewByIds();
        BluetoothManager mBluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter bluetoothAdapter = mBluetoothManager.getAdapter();
        if(!(bluetoothAdapter.isEnabled())){
            Intent enableIntent=new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableIntent,REQUEST_ENABLE_BLUETOOTH);
        }
        implementation();
    }

    private void findViewByIds() {

        discover=(Button)findViewById(R.id.button21);
        someTips=(Button)findViewById(R.id.button41);
        logout=(Button)findViewById(R.id.button3);
        msg_box=(TextView)findViewById(R.id.textView3);
        status=(TextView) findViewById(R.id.textview2);
        finddevice=(Button)findViewById(R.id.finddevicebtn);
        records=(Button)findViewById(R.id.recordbtn);
        textView=(TextView)findViewById(R.id.textView2);

    }

    private void implementation() {
        finddevice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Set<BluetoothDevice> bluetoothDevices= bluetoothAdapter.getBondedDevices();
                String[] strings=new String[bluetoothDevices.size()];
                btArray=new BluetoothDevice[bluetoothDevices.size()];
                int index=0;
                if(bluetoothDevices.size()>0) {
                    for (BluetoothDevice bluetoothDevice : bluetoothDevices) {
                       strings[index]=bluetoothDevice.getName();
                       btArray[index]=bluetoothDevice;
                       index++;
                        if(bluetoothDevice.getName().equals(BT_NAME))
                        {
                            bluetoothDevice1 = bluetoothDevice;
                            break;
                        }
                }
                    status.setText("Listening");
            }
                status.setText("Bluetooth Device Found");
        }
        });

        discover.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ServerClass serverClass=new ServerClass();
                serverClass.start();
            }
        });

        someTips.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,getInformedActivity.class);
                startActivity(intent);

            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UtilsSharedPreferences.saveSharedSetting(MainActivity.this, "NotifyYourself", "false");
                UtilsSharedPreferences.SharedPrefesSAVE(getApplicationContext(), "");
                Intent LogOut = new Intent(getApplicationContext(), Login_Activity.class);
                startActivity(LogOut);
                finish();
            }
        });
        records.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,Main2ActivityRecord.class);
                startActivity(intent);
            }
        });

    }
    android.os.Handler handler=new android.os.Handler(new android.os.Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            switch (msg.what)
            {
                case STATE_LISTENING:
                    status.setText("STATE_LISTENING");
                    break;
                case STATE_CONNECTING:
                    status.setText("STATE_CONNECTING");
                    break;
                case STATE_CONNECTED:
                    status.setText("STATE_CONNECTED");
                    break;
                case STATE_CONNECTION_FAILED:
                    status.setText("STATE_CONNECTION_FAILED");
                    break;
                case STATE_MESSAGE_RECEIVED:
                    status.setText("STATE_MESSAGE_RECEIVED");
                    byte[] readBuff=(byte[])msg.obj;
                    String string=new String(readBuff,0,msg.arg1);
                    msg_box.setText(string);
                    break;
            }
            return true;
        }
    });
    private class ServerClass extends Thread{
        private BluetoothServerSocket serverSocket;
        ServerClass(){
            try {
                serverSocket=bluetoothAdapter.listenUsingRfcommWithServiceRecord(APP_Name,MY_UUID);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        public void run(){
            BluetoothSocket socket=null;
            //socket is always null
            while(socket==null){
                try {
                    Message message=Message.obtain();
                    message.what=STATE_CONNECTING;
                    handler.sendMessage(message);
                    socket=serverSocket.accept();
                } catch (IOException e) {
                    e.printStackTrace();
                    Message message=Message.obtain();
                    message.what=STATE_CONNECTION_FAILED;
                    handler.sendMessage(message);
                }
                if(socket!=null){
                    Message message=Message.obtain();
                    message.what=STATE_CONNECTED;
                    handler.sendMessage(message);
                    //code for send,receive
                    sendReceive=new SendReceive(socket);
                    sendReceive.start();
                    break;
                }
            }
        }
//        public void cancel() {
//            Log.d(APP_Name, "cancel: Canceling.");
//            try {
//                serverSocket.close();
//            } catch (IOException e) {
//                Log.e(APP_Name, "cancel: Close ofThread ServerSocket failed. " + e.getMessage() );
//            }
//        }
    }
    private class ClientClass extends Thread{
        private BluetoothSocket bluetoothSocket;
        private  BluetoothDevice bluetoothDevice;

        ClientClass(BluetoothDevice device){
         bluetoothDevice=device;
            try {
                bluetoothSocket=bluetoothDevice.createRfcommSocketToServiceRecord(MY_UUID);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        public void run(){
            try {
                bluetoothSocket.connect();
                Message message=Message.obtain();
                message.what=STATE_CONNECTED;
                handler.sendMessage(message);
                sendReceive=new SendReceive(bluetoothSocket);
                sendReceive.start();
            } catch (IOException e) {
               e.printStackTrace();
//                try {
//                    bluetoothSocket.close();
//                    Message message=Message.obtain();
//                    message.what=STATE_CONNECTION_FAILED;
//                    handler.sendMessage(message);
//                } catch (IOException e1) {
//                    e1.printStackTrace();
//                }

            }
        }
    }
    private class SendReceive extends Thread{
        private BluetoothSocket bluetoothSocket;
        private InputStream inputStream;
        private OutputStream outputStream;

        SendReceive(BluetoothSocket bSocket) {
            this.bluetoothSocket = bSocket;
            InputStream tempIn = null;
            OutputStream tempOut = null;
            try {
                tempIn = bluetoothSocket.getInputStream();
                tempOut = bluetoothSocket.getOutputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }
            inputStream= tempIn;
            outputStream= tempOut;
        }
        public void run() {
            byte[] buffer=new byte[1024];
            int bytes;
            //as we are always ready to receive
            while (true){
                try {
                    bytes=inputStream.read(buffer);
                    String string=new String(buffer,0,bytes);
                    Message message=Message.obtain();
                    message.what=STATE_CONNECTED;
                    handler.sendMessage(message);
                    if(string.equals("generate message!"))
                    msg_box.setText(string);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
//        public void write(byte[] bytes){
//            try {
//                outputStream.write(bytes);
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
    }
    public void checkUser(){
        Boolean Check = Boolean.valueOf(UtilsSharedPreferences.readSharedSetting(MainActivity.this, "NotifyYourself", "true"));

    Intent introIntent = new Intent(MainActivity.this, Login_Activity.class);
        introIntent.putExtra("NotifyYourself", Check);

        if (Check) {
        startActivity(introIntent);
    }
    //testing purpose
        Toast.makeText(getApplicationContext(),"u r already logged in",Toast.LENGTH_LONG).show();
  }

}







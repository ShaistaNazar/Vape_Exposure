package com.example.dell.notifyyourself;

public class BluetoothDevice {
    String deviceName;
    android.bluetooth.BluetoothDevice bluetoothDevice;
    BluetoothDevice(String name, android.bluetooth.BluetoothDevice bluetoothDevice){
        this.deviceName=name;
        this.bluetoothDevice=bluetoothDevice;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public android.bluetooth.BluetoothDevice getBluetoothDevice() {
        return bluetoothDevice;
    }
}

package com.example.dell.notifyyourself;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class Login_Activity extends AppCompatActivity {
    Login_Activity login_activity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_);
        final EditText user,pass;
        ImageView welcome;
        TextView log_inText;
        Button login;


            user=(EditText)findViewById(R.id.user);
            pass=(EditText)findViewById(R.id.pass);
            login=(Button)findViewById(R.id.login);
            welcome=(ImageView)findViewById(R.id.imageView2);
            log_inText=(TextView)findViewById(R.id.textView4);

            login.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    UtilsSharedPreferences.saveSharedSetting(Login_Activity.this, "NotifyYourself", "false");
                   UtilsSharedPreferences.SharedPrefesSAVE(getApplicationContext(),user.getText().toString());
                   UtilsSharedPreferences.SharedPrefesSAVE(getApplicationContext(),pass.getText().toString());
                    Intent ImLoggedIn = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(ImLoggedIn);
                   // login_activity.finish();
                    finish();
                }
            });
        }
    }

